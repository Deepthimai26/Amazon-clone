import React from 'react'
import download from '../images/download.png'
import cart2 from '../images/cart2.png'
import location from '../images/location.png'
import india from '../images/india.png'
const Header = () => {
  return (
    <div className="Header">
      <div className="first-navbar">
    <img src={download} alt='logo' width="110" height="50"></img>
    <div className="location">
      <img src={location} alt="hlo" height='30' width="30"></img>
      <div>
        <p>Delivering to Attili 534134</p>
        <h5>Update location</h5>
      </div>
    </div>
    <div className="searchbar"></div>
    <div className="lang">
      <img src={india} alt="india" height="30" width="30"></img>
      <h5>EN</h5></div>
    <div>
      <p>Hello Sign in</p>
      <h5>Accounts&Lists</h5>
    </div>
    <div>
      <p>Returns</p>
      <h5>& orders</h5></div>
    <div className="cart">
      <img src={cart2} alt="hlo" width="30" height="30"></img>
      <h5>cart</h5>
    </div>
        

  </div>
    <div className="second-navbar">
    <h6>All</h6>
    <h6>MX Player</h6>
    <h6>Sell</h6>
    <h6>Best Sellers</h6>
    <h6>Today's Deals</h6>
    <h6>Mobiles</h6>
            <h6>Customer Service</h6>
            <h6>Electronics</h6>
            <h6>Prime</h6>
            <h6>New Releases</h6>
            <h6>Amazon Pay</h6>
            <h6>Home & Kitchen</h6>
            <h6>Fashion</h6>
            <h6>Computers</h6>
      

    </div>

</div>
    
  )
}

export default Header
