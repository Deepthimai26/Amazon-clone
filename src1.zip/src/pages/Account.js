
import React,{useContext} from 'react';
import Usercontext from './Usercontext';

const Account = () => {

  var details=useContext(Usercontext)
  const Logout=()=>{
    localStorage.removeItem("user_id")
    window.location.replace("/home")
  }


  return (

    <div>
      {details && details.length > 0 ? (
  <div className="container mt-4">
  <div className="row align-items-center border p-3 shadow rounded bg-light">
    <div className="col-md-4 text-center">
      <img 
        src={details[0].profile_picture} 
        alt="Profile" 
        className="rounded-circle border border-primary" 
        width="120" 
        height="120"
      />
    </div>
    <div className="col-md-8">
    <h2 className="text-primary">{details[0].username }</h2>
    <h4 className="text-muted">{details[0].user_id }</h4>
    <h4 className="text-muted">{details[0].registration_date }</h4>
    <h4 className="text-muted">{details[0].address}</h4>
      <h4 className="text-muted">{details[0][9] }</h4>
      <button onClick={()=>{Logout()}} type="button" class="btn btn-outline-primary me-2">Logout</button>
    </div>
  </div>
</div>
) : (
  <></>
)}
    </div>
  )
}

export default Account