function Body(){
  return (
    <div className="container">

    </div>
  )

}

export default Body