import React from 'react'

const Aboutpage = () => {
  return (
    <div className='d-flex flex-wrap'>
      <div className='col-12 col-sm-6 col-md-3 col-lg-3   bg-primary'><h2>THIS IS HEADING 1</h2></div>
      <div className='col-12 col-sm-6 col-md-3 col-lg-3   bg-danger'><h2>THIS IS HEADING 1</h2></div>
      <div className='col-12 col-sm-6 col-md-3 col-lg-3   bg-info'><h2>THIS IS HEADING 1</h2></div>
      <div className='col-12 col-sm-6 col-md-3 col-lg-3  bg-success'><h2>THIS IS HEADING 1</h2></div>
    </div>
  )
}

export default Aboutpage