import  { createContext } from 'react'

const Usercontext = createContext()
 

export default Usercontext